<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

$msg = "";
if(isset($_SESSION['msg'])){
    $msg = $_SESSION['msg'];
    unset($_SESSION['msg']);
}

// Fetch accounts for display
include "../config/connection.php";
$accounts = mysqli_query($conn, "SELECT accounts.*, users.name FROM accounts JOIN users ON accounts.user_id = users.id");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">

<h2>Welcome Admin</h2>

<?php if($msg) echo "<p class='msg'>$msg</p>"; ?>

<nav style="margin-bottom:20px;">
    <a href="create_user.php">Create_Account</a> |
    <a href="search_accounts.php">Search_Accounts</a> |
    <a href="loans.php">Manage Loans</a> |
    <a href="reports.php">Reports</a> |
        <a href="list_account.php">view all_account</a> |
    <a href="../auth/logout.php">Logout</a>
   
</nav>

<?php if(mysqli_num_rows($accounts) > 0): ?>
    <?php while($row = mysqli_fetch_assoc($accounts)): ?>
    <tr>
        <td><?= htmlspecialchars($row['account_no']) ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= $row['balance'] ?></td>
        <td>
            <a href="view_account.php?id=<?= $row['id'] ?>">View</a> |
            <a href="close_account.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to close this account?')">Close</a>
        </td>
    </tr>
    <?php endwhile; ?>
<?php else: ?>
   
<?php endif; ?>

</table>

</div>
</body>
</html>
