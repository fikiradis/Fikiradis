<?php 
session_start();
include "../config/connection.php";

// Get account ID from URL
$id = $_GET['id'] ?? 0;
$id = intval($id);

// Fetch account details
$acc_res = $conn->query("SELECT * FROM accounts WHERE id=$id");
if($acc_res->num_rows == 0){
    die("Account not found.");
}
$acc = $acc_res->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account Details</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        /* Internal CSS for Back to Dashboard button */
        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: lightblue;
            color: black;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            transition: 0.3s;
        }
        .back-button:hover {
            background-color: #00aaff;
            color: white;
        }

        /* Centering the button */
        .center {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>

<h2 style="text-align:center; color:#007bff;">Account Details</h2>

<div style="max-width:300px; margin:auto; text-align:center; border:1px solid #9d13c7ff; padding:15px; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1);">
    <img src="<?= $acc['image'] ?>" width="80" style="border-radius:50%; margin-bottom:10px;"><br>
    <b><?= htmlspecialchars($acc['name']) ?></b><br>
    Account No: <?= $acc['account_no'] ?><br>
    Balance: <?= $acc['balance'] ?><br>
    Status: <?= ucfirst($acc['status']) ?><br><br>
    <a href="close_account.php?id=<?= $acc['id'] ?>" 
       style="padding:5px 10px; background:red; color:lightblue; text-decoration:none; border-radius:4px;">Close Account</a>
</div>

<hr style="margin:30px 0;">

<!-- Your deposits, withdrawals, and transfers tables here -->

<!-- Back to Dashboard button -->
<div class="center">
    <a href="dashboard.php" class="back-button">⬅ Back to Dashboard</a>
</div>

</body>
</html>
