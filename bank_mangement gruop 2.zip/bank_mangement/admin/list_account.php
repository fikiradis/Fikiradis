<?php
session_start();
include "../config/connection.php";

// Fetch all accounts
$r = $conn->query("SELECT * FROM accounts ORDER BY account_no ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Accounts</title>
    <style>
        /* Table styling */
        table {
            width: 70%;
            border-collapse: collapse;
            text-align: center;
        }
        table th, table td {
            padding: 8px;
            border: 1px solid #007bff;
        }
        table th {
            background-color: #007bff;
            color: white;
        }

        /* Buttons */
        .btn {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
        }
        .btn-view {
            background-color: #007bff;
            color: white;
            margin-right: 5px;
        }
        .btn-close {
            background-color: red;
            color: white;
        }

        /* Back to Dashboard button */
        .back-button {
            display: inline-block;
            padding: 8px 15px;
            background-color: lightblue;
            color: black;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }
        .back-button:hover {
            background-color: #00aaff;
            color: white;
        }

        /* Centering */
        .center {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body  bgcolor="lightblue">

<h2 style="text-align:center; color:#007bff;">All Accounts List</h2>

<table style="margin:auto;">

    <tr>
        <th>Image</th>
        <th>Account Number</th>
        <th>Name</th>
        <th>Balance</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>

    <?php while($a = $r->fetch_assoc()): ?>
    <tr>
        <td><img src="<?= $a['image'] ?>" width="50" style="border-radius:50%;"></td>
        <td><?= $a['account_no'] ?></td>
        <td><?= htmlspecialchars($a['name']) ?></td>
        <td><?= $a['balance'] ?></td>
        <td><?= ucfirst($a['status']) ?></td>
        <td>
            <a href="view_account.php?id=<?= $a['id'] ?>" class="btn btn-view">View</a>
            <a href="close_account.php?id=<?= $a['id'] ?>" class="btn btn-close">Close</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- Centered Back to Dashboard button -->
<div class="center">
    <a href="dashboard.php" class="back-button">⬅ Back to Dashboard</a>
</div>

</body>
</html>
