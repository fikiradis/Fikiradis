<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

include "../config/connection.php";

// Transaction summary
$transactions = mysqli_query($conn,"SELECT * FROM transactions ORDER BY trans_date DESC");

// Loans summary (join users to get name)
$loans = mysqli_query($conn,"SELECT loans.*, users.name 
                            FROM loans 
                            JOIN users ON loans.user_id = users.id 
                            ORDER BY loans.applied_date DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reports</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">
<h2>Transaction Reports</h2>
<table border="1" width="100%" cellpadding="8" cellspacing="0">
<tr style="background:#cce5ff;">
    <th>Account</th>
    <th>Type</th>
    <th>Amount</th>
    <th>Date</th>
</tr>

<?php if(mysqli_num_rows($transactions) > 0): ?>
    <?php while($row = mysqli_fetch_assoc($transactions)): ?>
        <tr>
            <td><?= htmlspecialchars($row['account_no']) ?></td>
            <td><?= htmlspecialchars($row['type']) ?></td>
            <td><?= $row['amount'] ?></td>
            <td><?= $row['trans_date'] ?></td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="4" style="text-align:center;color:red;">No transactions found</td>
</tr>
<?php endif; ?>
</table>

<br>

<h2>Loans Reports</h2>
<table border="1" width="100%" cellpadding="8" cellspacing="0">
<tr style="background:#cce5ff;">
    <th>User</th>
    <th>Amount</th>
    <th>Status</th>
    <th>Applied Date</th>
</tr>

<?php if(mysqli_num_rows($loans) > 0): ?>
    <?php while($row = mysqli_fetch_assoc($loans)): ?>
        <tr>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= $row['loan_amount'] ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td><?= $row['applied_date'] ?></td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="4" style="text-align:center;color:red;">No loans found</td>
</tr>
<?php endif; ?>
</table>

<br>
<a href="dashboard.php">⬅ Back to Admin Dashboard</a>

</div>

</body>
</html>

