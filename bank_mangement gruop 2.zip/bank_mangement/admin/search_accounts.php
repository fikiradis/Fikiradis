<?php
session_start();

// Only admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access Denied");
}

include "../config/connection.php";

$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $key = trim($_POST['key'] ?? '');

    if ($key !== '') {
        $stmt = $conn->prepare(
            "SELECT name, account_no, balance, status 
             FROM accounts 
             WHERE name LIKE ? OR account_no = ?"
        );

        $likeKey = "%$key%";
        $stmt->bind_param("ss", $likeKey, $key);
        $stmt->execute();

        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $results[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Accounts</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">
    <h2>Search Accounts</h2>

    <form method="post">
        <input 
            type="text" 
            name="key" 
            placeholder="Account name or number"
            required
        >
        <button type="submit">Search</button>
    </form>

    <hr>

    <!-- Search Results -->
    <?php if (!empty($results)) { ?>
        <h4>Search Results</h4>
        <table border="1" cellpadding="5" cellspacing="0">
            <tr>
                <th>Name</th>
                <th>Account No</th>
                <th>Balance</th>
                <th>Status</th>
            </tr>

            <?php foreach ($results as $a) { ?>
                <tr>
                    <td><?= htmlspecialchars($a['name']) ?></td>
                    <td><?= htmlspecialchars($a['account_no']) ?></td>
                    <td><?= htmlspecialchars($a['balance']) ?></td>
                    <td><?= htmlspecialchars($a['status']) ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') { ?>
        <p><strong>No account found.</strong></p>
    <?php } ?>

    <br>
    <a href="dashboard.php">⬅ Back</a>
</div>

</body>
</html>

