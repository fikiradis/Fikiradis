

<?php
session_start();
if($_SESSION['role']!='user'){ die("Access Denied"); }

include "../config/connection.php";

if($_POST){
    $from_acc = $_POST['from_account'];
    $to_acc = $_POST['to_account'];
    $amt = $_POST['amount'];

    if(!is_numeric($amt) || $amt <= 0){
        die("Invalid amount");
    }
    if($from_acc == $to_acc){
        die("Cannot transfer to the same account");
    }

    // Check sender balance
    $res = $conn->query("SELECT balance FROM accounts WHERE account_no='$from_acc' AND status='active'");
    if($res->num_rows == 0){
        die("Sender account not found");
    }
    $sender = $res->fetch_assoc();
    if($sender['balance'] < $amt){
        die("Insufficient balance in sender account");
    }

    // Check receiver exists
    $res2 = $conn->query("SELECT * FROM accounts WHERE account_no='$to_acc' AND status='active'");
    if($res2->num_rows == 0){
        die("Receiver account not found");
    }

    // Perform transfer
    $conn->query("UPDATE accounts SET balance = balance - $amt WHERE account_no='$from_acc'");
    $conn->query("UPDATE accounts SET balance = balance + $amt WHERE account_no='$to_acc'");

    // Insert into transfers
    $conn->query("INSERT INTO transfers(from_account, to_account, amount) VALUES ('$from_acc', '$to_acc', $amt)");

    // header("Location: transfer_history.php");
    // exit;
      echo "Transfer balance successful!";
}


// Fetch active accounts
$r = $conn->query("SELECT account_no FROM accounts WHERE status='active'");
?>


<!DOCTYPE html>
<html>
<head>
<title>Transfer Money</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">

<h2>Transfer Money</h2>
<form method="post">
   


      <label>From Account:</label>
         <input 
            type="number" 
            name="from_account" 
            min="50" 
            placeholder="Enter account number " 
            required
        >
        <br>

   

<label>To Account:</label>
         <input 
            type="number" 
            name="to_account" 
            placeholder="recived  account number " 
            required
        >
        <br>


    <label>Amount:</label>
    <input type="number" name="amount" min="1"  placeholder="please enter amount "  required><br>
    <button type="submit">Transfer</button>
</form>
<a href="dashboard.php">Back</a>
</div>

</body>
</html>




