<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

include "../config/connection.php";

if(isset($_GET['id'])){
    $id = intval($_GET['id']); // Account/User ID

    // Check if account exists
    $check = mysqli_query($conn, "SELECT * FROM accounts WHERE id=$id");
    if(mysqli_num_rows($check) == 0){
        $_SESSION['msg'] = "Account not found.";
        header("Location: dashboard.php");
        exit();
    }

    // Fetch account_no before deletion
    $acc = mysqli_fetch_assoc($check);
    $account_no = $acc['account_no'];

    // Delete dependent records first
    mysqli_query($conn, "DELETE FROM transactions WHERE account_no='$account_no'");
    mysqli_query($conn, "DELETE FROM loans WHERE user_id=$id");

    // Delete account
    $delete_acc = mysqli_query($conn, "DELETE FROM accounts WHERE id=$id");

    // Delete associated user
    $delete_user = mysqli_query($conn, "DELETE FROM users WHERE id=$id");

    if($delete_acc && $delete_user){
        $_SESSION['msg'] = "Account Closed Successfully.";
    } else {
        $_SESSION['msg'] = "Failed to close account. Try again.";
    }

    // Redirect to dashboard
    header("Location: dashboard.php");
    exit();
}

// If no ID provided, redirect to dashboard
header("Location: dashboard.php");
exit();
?>

