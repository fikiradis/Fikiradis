-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2025 at 08:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `transfers`
--

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL,
  `from_account` varchar(13) NOT NULL,
  `to_account` varchar(13) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transfer_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transfers`
--

INSERT INTO `transfers` (`id`, `from_account`, `to_account`, `amount`, `transfer_date`) VALUES
(1, '1000489053466', '1000205717222', 100.00, '2025-12-23 22:37:46'),
(2, '1000489053466', '1000205717222', 100.00, '2025-12-23 22:38:25'),
(3, '1000489053466', '1000205717222', 100.00, '2025-12-23 22:38:43'),
(4, '1000489053466', '1000205717222', 300.00, '2025-12-23 22:39:13'),
(5, '1000489053466', '1000205717222', 300.00, '2025-12-23 22:39:38'),
(6, '1000489053466', '1000205717222', 300.00, '2025-12-23 22:41:59'),
(7, '1000489053466', '1000205717222', 600.00, '2025-12-23 22:45:05'),
(8, '1000489053466', '1000530857984', 700.00, '2025-12-23 22:47:04'),
(9, '1000530857984', '1000489053466', 300.00, '2025-12-23 22:47:57'),
(10, '1000530857984', '1000489053466', 300.00, '2025-12-23 22:48:26'),
(11, '1000489053466', '1000205717222', 180.00, '2025-12-23 23:15:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transfers`
--
ALTER TABLE `transfers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_account` (`from_account`),
  ADD KEY `to_account` (`to_account`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transfers`
--
ALTER TABLE `transfers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transfers`
--
ALTER TABLE `transfers`
  ADD CONSTRAINT `transfers_ibfk_1` FOREIGN KEY (`from_account`) REFERENCES `accounts` (`account_no`),
  ADD CONSTRAINT `transfers_ibfk_2` FOREIGN KEY (`to_account`) REFERENCES `accounts` (`account_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
