<?php
include "../config/connection.php";

if(isset($_POST['send'])){
    $name    = mysqli_real_escape_string($conn, $_POST['name']);
    $email   = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    if($name=="" || $email=="" || $message==""){
        echo "<h3 style='color:red;text-align:center;'>All fields are required</h3>";
        echo "<a href='contact.html'>Go Back</a>";
        exit();
    }

    $sql = "INSERT INTO contact_messages(name,email,message)
            VALUES('$name','$email','$message')";

    if(mysqli_query($conn,$sql)){
        echo "
        <div style='text-align:center;margin-top:50px;'>
            <h2 style='color:green;'>Message Sent Successfully</h2>
            <p>Thank you for contacting us.</p>
            <a href='index.php'>Back to Home</a>
        </div>";
    }else{
        echo "Error: ".mysqli_error($conn);
    }
}else{
    header("Location: contact.php");
}
?>
