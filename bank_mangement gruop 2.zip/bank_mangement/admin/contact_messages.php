<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role']!='admin'){
    header("Location: ../public/login.html");
    exit();
}

include "../config/connection.php";

// Fetch messages
$result = mysqli_query($conn,"SELECT * FROM contact_messages ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Contact Messages</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">
<h2>📩 Contact Messages</h2>

<table border="1" width="100%" cellpadding="8" cellspacing="0">
<tr style="background:#cce5ff;color:#004085;">
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Message</th>
    <th>Date</th>
</tr>

<?php if(mysqli_num_rows($result)>0){ ?>
    <?php while($row = mysqli_fetch_assoc($result)){ ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
        <td><?= $row['created_at'] ?></td>
    </tr>
    <?php } ?>
<?php }else{ ?>
<tr>
    <td colspan="5" style="text-align:center;color:red;">No Messages Found</td>
</tr>
<?php } ?>

</table>

<br>
<a href="dashboard.php">⬅ Back to Dashboard</a>

</div>

</body>
</html>

