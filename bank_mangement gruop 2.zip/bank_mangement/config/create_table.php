<?php

// STEP 1.1: CONNECT TO MYSQL

$conn = mysqli_connect("localhost", "root", "");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// STEP 1.2: CREATE DATABASE

$db = "bank_system";
$sql = "CREATE DATABASE IF NOT EXISTS $db";
if (!mysqli_query($conn, $sql)) {
    die("Database creation failed");
}
echo "Database created successfully <br>";


// STEP 1.3: SELECT DATABASE

mysqli_select_db($conn, $db);

// Disable FK checks for drop
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");


// USERS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS users");
$users = "
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('admin','user') NOT NULL
)";
mysqli_query($conn, $users);
echo "Users table created <br>";


// ACCOUNTS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS accounts");
$accounts = "
CREATE TABLE accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    account_no VARCHAR(13) UNIQUE NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0,
    image VARCHAR(100),
    status ENUM('active','closed') DEFAULT 'active')";
mysqli_query($conn, $accounts);
echo "Accounts table created <br>";


// TRANSACTIONS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS transactions");
$trans = "
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    account_no VARCHAR(13) NOT NULL,
    type VARCHAR(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    trans_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_no) REFERENCES accounts(account_no)
)";
mysqli_query($conn, $trans);
echo "Transactions table created <br>";


// DEPOSITS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS deposits");
$dep = "
CREATE TABLE deposits (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(13) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    deposit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_number) REFERENCES accounts(account_no)
)";
mysqli_query($conn, $dep);
echo "Deposits table created <br>";

// WITHDRAWALS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS withdrawals");
$wit = "
CREATE TABLE withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(13) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    withdraw_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_number) REFERENCES accounts(account_no)
)";
mysqli_query($conn, $wit);
echo "Withdrawals table created <br>";


// TRANSFERS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS transfers");
$tr = "CREATE TABLE transfers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_account VARCHAR(13) NOT NULL,
    to_account VARCHAR(13) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transfer_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_account) REFERENCES accounts(account_no),
    FOREIGN KEY (to_account) REFERENCES accounts(account_no)
)";
mysqli_query($conn, $tr);
echo "Transfers table created <br>";

// LOANS TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS loans");
$loan = "
CREATE TABLE loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    loan_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";
mysqli_query($conn, $loan);
echo "Loans table created <br>";


// CONTACT MESSAGES TABLE

mysqli_query($conn, "DROP TABLE IF EXISTS contact_messages");
$contact = "
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
mysqli_query($conn, $contact);
echo "Contact messages table created <br>";


// INSERT DEFAULT USERS

$check = mysqli_query($conn, "SELECT * FROM users WHERE username='admin'");
if (mysqli_num_rows($check) == 0) {
    mysqli_query($conn, "
        INSERT INTO users (name, username, password, role)
        VALUES 
        ('Admin','admin','admin123','admin'),
        ('User','user','user123','user')
    ");
    echo "Default admin and user created <br>";
}

// Enable FK checks
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");

echo "<h3>STEP 1 COMPLETED SUCCESSFULLY</h3>";
?>
