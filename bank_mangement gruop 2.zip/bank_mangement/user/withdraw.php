




<?php

session_start();
if($_SESSION['role']!='user'){ die("Access Denied"); }

include "../config/connection.php";

if($_POST){
    $acc = $_POST['account_no'];
    $amt = $_POST['amount'];

    if(!is_numeric($amt) || $amt <= 0){
        die("Invalid amount");
    }

    // Check account exists and has enough balance
    $res = $conn->query("SELECT balance FROM accounts WHERE account_no='$acc' AND status='active'");
    if($res->num_rows == 0){
        die("Account not found or inactive");
    }
    $row = $res->fetch_assoc();
    if($row['balance'] < $amt){
        die("Insufficient balance");
    }
else{
    echo"withdraw sucessful";
}
    // Update balance
    $conn->query("UPDATE accounts SET balance = balance - $amt WHERE account_no='$acc'");

    // Insert into withdrawals
    $conn->query("INSERT INTO withdrawals(account_number, amount) VALUES ('$acc', $amt)");
}

// Fetch active accounts
$r = $conn->query("SELECT account_no FROM accounts WHERE status='active'");
?>


<!DOCTYPE html>
<html>
<head>
<title>Withdraw</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">
<h2>Withdraw Money</h2>
<form method="post">
  

     <label>Account Number:</label>
         <input 
            type="number" 
            name="account_no" 
            min="100" 
            placeholder="please Enter account number " 
            required  >
        <br>


    <label>Amount:</label>
    <input type="number" name="amount" min="100"    placeholder="please Enter amount " required><br>
    <button type="submit">Withdraw</button>
</form>

<a href="dashboard.php">Back</a>
</div>

</body>
</html>




