<?php
session_start();

if (!isset($_SESSION['uid']) || $_SESSION['role'] != 'user') {
    die("Access Denied");
}

include "../config/connection.php";

$uid = intval($_SESSION['uid']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $acc = $_POST['account_no'];
    $amt = $_POST['amount'];

    // Validate amount
    if (!is_numeric($amt) || $amt <= 0) {
        die("Invalid amount");
    }

    // Check account exists and is active
    $check = $conn->query(
        "SELECT balance FROM accounts 
         WHERE account_no='$acc' AND status='active'"
    );

    if ($check->num_rows == 0) {
        die("Account not found or inactive");
    }

    // Update account balance
    $conn->query(
        "UPDATE accounts 
         SET balance = balance + $amt 
         WHERE account_no='$acc'"
    );

    // Insert into deposits table
    $conn->query(
        "INSERT INTO deposits (account_number, amount, user_id, deposit_date) 
         VALUES ('$acc', $amt, $uid, NOW())"
    );

    $success = "Deposit successful!";
}

// Fetch active accounts for dropdown
$r = $conn->query(
    "SELECT account_no 
     FROM accounts 
     WHERE status='active'"
);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Deposit Money</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">

    <h2>Deposit Money</h2>

    <?php if (!empty($success)) { ?>
        <p style="color:green;"><?= $success ?></p>
    <?php } ?>

    <form method="post">

        <label>Account Number:</label>
         <input 
            type="number" 
            name="account_no" 
            min="100" 
            placeholder="Enter account number " 
            required
        >
        <br>

        <label>Amount:</label>
        <input 
            type="number" 
            name="amount" 
            min="1" 
            placeholder="Enter deposit amount" 
            required><br>

        <button type="submit">Deposit</button>
    </form>

    <a href="dashboard.php">Back</a>

</div>

</body>
</html>





