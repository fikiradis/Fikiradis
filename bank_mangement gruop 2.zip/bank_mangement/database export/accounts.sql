-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2025 at 08:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `account_no` varchar(13) NOT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `image` varchar(100) DEFAULT NULL,
  `status` enum('active','closed') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `user_id`, `name`, `account_no`, `balance`, `image`, `status`) VALUES
(2, 0, 'Anter BOL', '1000435678987', 3000.00, 'uploads/1766557471_photo_2025-12-21_22-23-26.jpg', 'active'),
(3, 0, 'Fikiradis Enyihe', '1000489053466', 2300.00, 'uploads/1766557509_1765991744_photo_2025-12-17_17-37-29.jpg', 'active'),
(4, 0, 'Senait Kiros', '1000530857984', 6100.00, 'uploads/1766557544_1765989417_photo_2025-12-17_17-37-19.jpg', 'active'),
(5, 0, 'Bekele Abebe', '1000430650987', 40000.00, 'uploads/1766557579_photo_2025-12-21_22-22-57.jpg', 'active'),
(6, 0, 'Demeku Yihiyies', '1000205717222', 9800.00, 'uploads/1766557617_1765982510_photo_2025-12-17_17-37-05.jpg', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_no` (`account_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
