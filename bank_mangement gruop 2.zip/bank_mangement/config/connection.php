<?php
// Database configuration
$host = "localhost";
$user = "root";
$pass = "";
$db   = "bank_system";

// Create connection
$conn = mysqli_connect($host, $user, $pass, $db);

// Check connection
if(!$conn){
    die("Database connection failed");
}
?>
