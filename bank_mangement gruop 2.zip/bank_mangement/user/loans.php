<?php
session_start();
if($_SESSION['role']!='user'){ die("Access Denied"); }

include "../config/connection.php";
$uid = $_SESSION['uid'];

// Apply loan
if(isset($_POST['apply'])){
    $amount = $_POST['amount'];
    if($amount <= 0){
        echo "<p class='error'>Invalid amount</p>";
    }else{
        mysqli_query($conn,"INSERT INTO loans(user_id,loan_amount)
                            VALUES($uid,$amount)");
        echo "<p class='msg'>Loan applied successfully</p>";
    }
}

// View own loans
$loans = mysqli_query($conn,"SELECT * FROM loans WHERE user_id=$uid ORDER BY applied_date DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>My Loans</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">
<h2>My Loans</h2>

<form method="post">

     <label>Account Number:</label>
         <input 
            type="number" 
            name="account_no" 
            min="100" 
            placeholder="please Enter account number " 
            required>  <br>
 <label>amount:</label>
<input type="number" name="amount" placeholder="please enter Loan Amount" required><br>
<button name="apply">Apply Loan</button>
</form>

<h3>Loan History</h3>
<table>
<tr>
<th>Amount</th>
<th>Status</th>
<th>Date</th>
</tr>

<?php
while($row=mysqli_fetch_assoc($loans)){
    echo "<tr>
    <td>{$row['loan_amount']}</td>
    <td>{$row['status']}</td>
    <td>{$row['applied_date']}</td>
    </tr>";
}
?>
</table>

<a href="dashboard.php">Back</a>
</div>
</body>
</html>
