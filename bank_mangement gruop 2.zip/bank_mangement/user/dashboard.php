<?php
session_start();
if(!isset($_SESSION['uid']) || $_SESSION['role'] != 'user'){
    header("Location: ../public/login.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
<h2>Welcome User page: <?= $_SESSION['name'] ?></h2>

<a href="deposit.php">Deposit</a> |
<a href="withdraw.php">Withdraw</a> |
<a href="transfer.php">Transfer</a> |
<a href="loans.php">Loans</a> |
<a href="../auth/logout.php">Logout</a>
</div>
</body>
</html>

