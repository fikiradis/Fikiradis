<?php
session_start();
if($_SESSION['role']!='admin'){ die("Access Denied"); }

include "../config/connection.php";

// Approve / Reject action
if(isset($_GET['approve'])){
    $id = intval($_GET['approve']);
    mysqli_query($conn,"UPDATE loans SET status='approved' WHERE id=$id");
}
if(isset($_GET['reject'])){
    $id = intval($_GET['reject']);
    mysqli_query($conn,"UPDATE loans SET status='rejected' WHERE id=$id");
}

// Get all loans (use users.name)
$loans = mysqli_query($conn,"SELECT loans.*, users.name 
                            FROM loans 
                            JOIN users ON loans.user_id=users.id
                            ORDER BY loans.applied_date DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Loans Management</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<div class="container">
<h2>Loans Management</h2>

<table border="1" width="100%" cellpadding="8" cellspacing="0">
<tr style="background:#cce5ff;">
<th>User</th>
<th>Amount</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php
while($row=mysqli_fetch_assoc($loans)){
    echo "<tr>
    <td>".htmlspecialchars($row['name'])."</td>
    <td>{$row['loan_amount']}</td>
    <td>".htmlspecialchars($row['status'])."</td>
    <td>";
    if($row['status']=='pending'){
        echo "<a href='loans.php?approve={$row['id']}'>Approve</a> | ";
        echo "<a href='loans.php?reject={$row['id']}'>Reject</a>";
    }
    echo "</td></tr>";
}
?>
</table>

<br>
<a href="dashboard.php">⬅ Back</a>
</div>
</body>
</html>

