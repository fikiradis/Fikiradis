

<?php

session_start();
if($_SESSION['role']!='admin'){ die("Access Denied"); }

include "../config/connection.php";
// Check if form submitted
if($_POST){

    // Clean inputs
    $name = ($_POST['name']);
    $acc  = ($_POST['account_no']);
    $bal  = ($_POST['balance']);

    // ---------- VALIDATION ----------
    if(!preg_match("/^[A-Za-z ]+$/",$name)){
        die("<p class='error'>Name must contain letters only.</p>");
    }

    if(!preg_match("/^(1000|4229)[0-9]{9}$/",$acc)){
        die("<p class='error'>Invalid account number. Must start with 1000 or 4229 + 9 digits.</p>");
    }

    if(!is_numeric($bal) || $bal < 0){
        die("<p class='error'>Invalid balance amount.</p>");
    }

    // ---------- IMAGE UPLOAD ----------
    $uploadDir = "uploads/";
    if(!is_dir($uploadDir)){
        mkdir($uploadDir, 0777, true);
    }

    $imgName = "";
    if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        $target = $uploadDir . $imgName;

        if(!move_uploaded_file($_FILES['image']['tmp_name'], $target)){
            echo "<p class='error'>Image upload failed. Account will be created without image.</p>";
            $imgName = "";
        }
    }

    // ---------- INSERT INTO DATABASE ----------
    $imgPath = $imgName ? $uploadDir . $imgName : "";

    $sql = "INSERT INTO accounts(account_no,name,balance,image) 
            VALUES('$acc','$name','$bal','$imgPath')";

    if($conn->query($sql)){
        echo "<p class='success'>Account Created Successfully!</p>";
    } else {
        echo "<p class='error'>Error: " . $conn->error . "</p>";
    }
}
?>

<!-- ---------- FORM ---------- -->


<!DOCTYPE html>
<html>
<head>
<title>Create User</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">

<h3>Create Account</h3>
<form action="" method="post" enctype="multipart/form-data">
    <input name="name" placeholder="Name" required>
    <input name="account_no" placeholder="Account Number" required>
    <input type="number" name="balance" placeholder="Initial Balance" required>
    <input type="file" name="image"><br>
    <button>Create</button>
</form>

<a href="dashboard.php">Back to Dashboard</a>
</div>

</body>
</html>

