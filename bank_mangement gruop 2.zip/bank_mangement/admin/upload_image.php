<?php
session_start();
if(!isset($_SESSION['uid']) || $_SESSION['role'] != 'admin'){
    header("Location: ../public/login.html");
    exit();
}

if(isset($_POST['upload'])){
    $target_dir = "../assets/images/";
    $target_file = $target_dir . "bank.jpg";
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false) {
        if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            echo "<h3 style='color:green;text-align:center;'>Image uploaded successfully.</h3>";
        } else {
            echo "<h3 style='color:red;text-align:center;'>Sorry, there was an error uploading your file.</h3>";
        }
    } else {
        echo "<h3 style='color:red;text-align:center;'>File is not an image.</h3>";
    }
}
echo "<a href='dashboard.php'>Back to Dashboard</a>";
?></content>
<parameter name="filePath">c:\xampp\htdocs\fikirbank\admin\upload_image.php