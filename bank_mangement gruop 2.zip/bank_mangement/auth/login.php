<?php
session_start();
include "../config/connection.php";

if(isset($_POST['username']) && isset($_POST['password'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT id, role, name, password FROM users WHERE username=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($result) == 1){
        $user = mysqli_fetch_assoc($result);

        // Verify password
        if($password == $user['password']){
            $_SESSION['uid'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];

            if($user['role'] == 'admin'){
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: ../user/dashboard.php");
            }
            exit();
        } else {
            header("Location: ../public/login.html?error=invalid");
        }
    } else {
        header("Location: ../public/login.html?error=invalid");
    }

    mysqli_stmt_close($stmt);
} else {
    // Handle case when POST data is not set, maybe redirect to login
    header("Location: ../public/login.html");
}
?>


